const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

const submissions = [];

// Route to handle form submission
app.post('/submit-form', (req, res) => {
    try {
        const formData = req.body;

        const { firstName, lastName, email, password, dob, gender, contact, pin, address } = formData;
        if (!firstName || !lastName || !email || !password || !dob || !gender || !contact || !pin || !address) {
            return res.status(400).json({ message: 'Please fill all required fields!' });
        }

        submissions.push(formData);

        res.status(201).json({ message: 'Form submitted successfully!', data: formData });
    } catch (error) {
        console.error('Error saving form data:', error);
        res.status(500).json({ message: 'Error saving form data' });
    }
});

// Route to display all submissions on the root page
app.get('/', (req, res) => {
    let html = `
        <h1>Submitted Details</h1>
        <table border="1" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Contact</th>
                    <th>Pin Code</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
    `;

    if (submissions.length > 0) {
        submissions.forEach(submission => {
            html += `
                <tr>
                    <td>${submission.firstName}</td>
                    <td>${submission.lastName}</td>
                    <td>${submission.email}</td>
                    <td>${submission.dob}</td>
                    <td>${submission.gender}</td>
                    <td>${submission.contact}</td>
                    <td>${submission.pin}</td>
                    <td>${submission.address}</td>
                </tr>
            `;
        });
    } else {
        html += `
            <tr>
                <td colspan="8" style="text-align: center;">No submissions yet</td>
            </tr>
        `;
    }

    html += `
            </tbody>
        </table>
    `;

    res.send(html);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
